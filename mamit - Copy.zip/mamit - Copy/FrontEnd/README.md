# TIMAM

A simple web application where users can get mental health services by making online appointments to physicians.
