<?php
$servername = "localhost";
$username = "root";
$password = "VuR4BCEAijKy";
$dbname = "timam_maindb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$service = $_POST['service'];
$doctor_name = $_POST['doctor_name'];
$message = $_POST['message'];


$sql = "INSERT INTO consultations (first_name, last_name, service, doctor_name, message, submission_date)
VALUES ('$first_name', '$last_name', '$service', '$doctor_name', '$message', NOW())";

mysqli_query($conn, $sql)
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Timam</title>
    <link rel="stylesheet" href="./css/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-lightblue container">
    <a class="navbar-brand" href="index.html">TIMAM</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="index.html"> <span><i class="fas fa-home mr-1"></i>Home</span><span
                        class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="index.html" id="navbarDropdown" role="button"
                   data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span><i class="fas fa-users mr-1"></i>Doctors</span>
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="#">Registered Doctors</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="#">Online Doctors</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="#">Live chat</a>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="index.html"><span><i class="fas fa-bell mr-1"></i>Notifications</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="index.html"><span><i class="far fa-newspaper mr-1"></i>Blog</span></a>
            </li>
        </ul>
        <div class="account">
            <span><i class="fas fa-user-circle"></i></span><br>
        </div>
    </div>
</nav>
<div class="container">
    <div class="services-heading">
        <h3 class="text-center">Thank you</h3>
    </div>

    <div class="">
        Thank you for scheduling an appointment. We will get back to you as soon as possible.
    </div>
    <div class="container">
        <div class="">
            <div class="row">
                <div class="col-12 col-lg-8 offset-lg-2">
                </div>
            </div>
        </div>

        <footer class="site-footer">
            <div class="footer-widgets">
                <div class="row">
                    <div class="col-12 col-md-6 col-lg-4">
                        <div class="foot-about">
                            <h2><a href="#"><img src="images/logo.png" alt=""></a></h2>

                            <p class="ml-10">Timam offers an innovative integrated full service approach, which aims to address every need associated with mental health.
                                This includes psychiatric, psychological, therapeutic and social aspects of a patient.</p>
                            <p class="copyright ml-20" style="font-size: 16px;">Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Timam Mental Health</p>
                        </div><!-- .foot-about -->
                    </div><!-- .col -->

                    <div class="col-12 col-md-6 col-lg-4 mt-5 mt-md-0">
                        <div class="foot-contact">
                            <h2>Contact</h2>

                            <ul class="p-0 m-0">
                                <li><span>Addtress:</span> Westlands Str. 26-27 Nairobi Kenya.</li>
                                <li><span>Phone:</span>+254 777777000</li>
                                <li><span>Email:</span>timam@gmail.com</li>
                                <li><a href=""><span><i class="fab fa-facebook fa-2x text-info"></i></span></a></li>
                                <li><a href=""><span><i class="fab fa-twitter fa-2x text-info""></i></span></a></li>
                                <li><a href=""><span><i class="fab fa-linkedin fa-2x text-info""></i></span></a></li>
                            </ul>
                        </div>
                    </div><!-- .col -->

                    <div class="col-12 col-md-6 col-lg-4 mt-5 mt-md-0">
                        <div class="foot-links">
                            <h2>Usefull Links</h2>

                            <ul class="p-0 m-0">
                                <li><a href="index.html">Home</a></li>
                                <li><a href="services.html">Services</a></li>
                                <li><a href="contact.html">Contact</a></li>
                                <li><a href="news.html">Blog</a></li>
                            </ul>
                            <h5>Live Chat</h5>
                            <ul><li><a href=""><span><i class="fas fa-comment-alt  text-info fa-3x"></i></span></a></li></ul>
                        </div><!-- .foot-links -->
                    </div><!-- .col -->
                </div><!-- .row -->
            </div><!-- .footer-widgets -->
        </footer><!-- .site-footer -->
    </div>

    <script src="js/scripts.js"></script>
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>